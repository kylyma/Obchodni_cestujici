use crate::io as io_utils;
use crate::tsp;
use crate::types::{Command, Point, Setup};
use itertools::Itertools;
use rand::prelude::*;
use std::io;
use std::io::Write;
use std::time::Instant;

fn format_duration(secs: f64) -> String {
    if secs < 60.0 {
        return format!("{secs:.3} sec");
    }
    let mut seconds = secs;
    let minutes = (seconds / 60.0).floor() as i64;
    seconds -= (minutes as f64) * 60.0;
    if minutes < 60 {
        return format!("{minutes} min {seconds:.3} sec");
    }
    let hours = (minutes / 60) as i64;
    let minutes2 = minutes - hours * 60;
    if hours < 24 {
        return format!("{hours} h {minutes2} min {seconds:.3} sec");
    }
    let days = hours / 24;
    let hours2 = hours - days * 24;
    format!("{days} d {hours2} h {minutes2} min {seconds:.3} sec")
}

/// Local brute-force correction: for each start position m, optimize the order of the next `window` cities (cyclic),
/// keeping the rest of the tour fixed.
///
/// This mirrors the original C "MojeOprava" idea. It is expensive (O(n * window!)),
/// but with a small window (default 6) it can still be acceptable for moderate n.
fn brute_local_correction(tour: &mut Vec<Point>, variant: i32, passes: usize, window: usize) -> f64 {
    let n = tour.len();
    if n < window + 2 {
        return 0.0;
    }

    let start = Instant::now();
    for _ in 0..passes {
        for m in 0..n {
            let prev = (m + n - 1) % n;
            let next = (m + window) % n;

            let idxs: Vec<usize> = (0..window).map(|t| (m + t) % n).collect();
            let window_pts: Vec<Point> = idxs.iter().map(|&ix| tour[ix]).collect();

            let mut best = window_pts.clone();
            let mut best_len = if variant >= 0 { f32::INFINITY } else { f32::NEG_INFINITY };

            for perm in window_pts.iter().copied().permutations(window) {
                let mut len = dist(tour[prev], perm[0]);
                for i in 0..window - 1 {
                    len += dist(perm[i], perm[i + 1]);
                }
                len += dist(perm[window - 1], tour[next]);

                let better = if variant >= 0 { len < best_len } else { len > best_len };
                if better {
                    best_len = len;
                    best = perm;
                }
            }

            for (dst, p) in idxs.into_iter().zip(best.into_iter()) {
                tour[dst] = p;
            }
        }
    }
    start.elapsed().as_secs_f64()
}

#[inline]
fn dist(a: Point, b: Point) -> f32 {
    let dx = a.x - b.x;
    let dy = a.y - b.y;
    (dx * dx + dy * dy).sqrt()
}

fn cooling_temperature(step: u64, cycles: u64, t0: f32, k: f32) -> f32 {
    // Cooling schedule used in the original C implementation:
    // T = (maxCycle*k*T0) / (cycle + (maxCycle*k - 1))
    let max_cycle = cycles as f64;
    let kf = k as f64;
    let t0f = t0 as f64;
    let denom = (step as f64) + (max_cycle * kf - 1.0);
    (max_cycle * kf * t0f / denom) as f32
}

pub fn run(cmd: Command) -> io::Result<()> {
    let mut rng = rand::rngs::StdRng::from_entropy();
    let z: f32 = 0.0;
    let mol_path = "trajectory.mol";

    let (name, mut setup, mut tour): (String, Setup, Vec<Point>) = match cmd {
        Command::Load { name, maximize } => {
            let set_path = format!("{name}.set");
            let conf_path = format!("{name}.conf");
            let mut setup = io_utils::read_set(&set_path)?;
            if maximize {
                setup.variant = -1;
            }
            setup.normalize();
            if setup.cities <= 4 {
                return Err(io::Error::new(io::ErrorKind::InvalidInput, "Number of cities must be > 4"));
            }
            let mut tour = io_utils::read_conf(&conf_path, setup.cities)?;
            if setup.mix {
                tour.shuffle(&mut rng);
            }
            (name, setup, tour)
        }
        Command::Generate {
            cities,
            name,
            cycles,
            print_every,
            t0,
            k,
            xsize,
            ysize,
            maximize,
        } => {
            if cities <= 4 {
                return Err(io::Error::new(io::ErrorKind::InvalidInput, "Number of cities must be > 4"));
            }
            let mut setup = Setup {
                cities,
                cycles,
                print_every,
                t0,
                k,
                variant: if maximize { -1 } else { 1 },
                xsize,
                ysize,
                mix: true,
            };
            setup.normalize();

            let mut tour = Vec::with_capacity(cities);
            for _ in 0..cities {
                let x = rng.gen_range(0.0f32..xsize);
                let y = rng.gen_range(0.0f32..ysize);
                tour.push(Point { x, y });
            }

            (name, setup, tour)
        }
    };

    // Output file names (compatible with the original C naming scheme)
    let trip_path = format!("{name}.trip");
    let conf_path = format!("{name}.conf");
    let set_path = format!("{name}.set");
    let fin_path = format!("{name}.fin");
    let plb_path = format!("{name}.plb");

    // Save initial configuration and setup for reproducibility
    io_utils::write_conf(&conf_path, &tour)?;
    io_utils::write_set(&set_path, &setup)?;

    // Create .plb and .mol
    io_utils::create_plb(&plb_path, [setup.cities as f32, -3.0])?;
    io_utils::create_mol(mol_path, setup.cities - 1, setup.cycles, setup.print_every, setup.t0, setup.k)?;
    io_utils::init_trip(&trip_path, &setup)?;

    // Write initial frame
    io_utils::append_frame_plb(&plb_path, setup.xsize, setup.ysize, z, &tour)?;
    let init_len = (setup.variant as f32) * tsp::tour_length(&tour);
    io_utils::append_trip_row(&trip_path, 1, setup.print_every, setup.t0, init_len)?;

    // Simulated annealing (2-opt moves)
    let korr = (setup.xsize * setup.ysize).sqrt().max(1e-12);
    let start = Instant::now();
    let mut temperature = setup.t0;

    for step in 1..=setup.cycles {
        temperature = cooling_temperature(step, setup.cycles, setup.t0, setup.k);

        let n = tour.len();
        let mut i = rng.gen_range(0..n);
        let mut k = i;
        while {
            let diff = if i > k { i - k } else { k - i };
            diff < 2 || diff == n - 1
        } {
            k = rng.gen_range(0..n);
        }
        if k < i {
            std::mem::swap(&mut i, &mut k);
        }

        let delta = tsp::delta_2opt(&tour, i, k) * (setup.variant as f32);
        let accept = if delta < 0.0 {
            true
        } else {
            let prob = (-(delta as f64) / ((temperature as f64) * (korr as f64))).exp();
            rng.gen::<f64>() < prob
        };

        if accept {
            tsp::apply_2opt(&mut tour, i, k);
        }

        if setup.print_every != 0 && step % setup.print_every == 0 {
            io_utils::append_frame_plb(&plb_path, setup.xsize, setup.ysize, z, &tour)?;
            let len = (setup.variant as f32) * tsp::tour_length(&tour);
            io_utils::append_trip_row(&trip_path, step, setup.print_every, temperature, len)?;
        }
    }

    if setup.print_every != 0 && setup.cycles % setup.print_every != 0 {
        io_utils::append_frame_plb(&plb_path, setup.xsize, setup.ysize, z, &tour)?;
        let len = (setup.variant as f32) * tsp::tour_length(&tour);
        io_utils::append_trip_row(&trip_path, setup.cycles, setup.print_every, temperature, len)?;
    }

    let sa_secs = start.elapsed().as_secs_f64();
    {
        let mut f = std::fs::OpenOptions::new().create(true).append(true).open(&trip_path)?;
        writeln!(f, "!Simulated annealing run time was {}", format_duration(sa_secs))?;
    }
    eprintln!("Simulated annealing run time was {}", format_duration(sa_secs));
    eprintln!("Final tour length from SA: {:.6}", tsp::tour_length(&tour));

    // Optional local correction (kept for compatibility)
    let corr_secs = brute_local_correction(&mut tour, setup.variant, 4, 6);
    let final_len = tsp::tour_length(&tour);
    io_utils::append_frame_plb(&plb_path, setup.xsize, setup.ysize, z, &tour)?;
    io_utils::append_trip_row(&trip_path, setup.cycles + 1, setup.print_every.max(1), temperature, (setup.variant as f32) * final_len)?;

    {
        let mut f = std::fs::OpenOptions::new().create(true).append(true).open(&trip_path)?;
        writeln!(f, "!My correction run time was {}", format_duration(corr_secs))?;
        writeln!(f, "!Trip length after my correction follows:")?;
        writeln!(f, "!Final length after My correction is: {:.6}", final_len)?;
    }
    eprintln!("My correction run time was {}", format_duration(corr_secs));
    eprintln!("Final length after correction: {:.6}", final_len);

    io_utils::write_conf(&fin_path, &tour)?;
    let total_secs = start.elapsed().as_secs_f64();
    eprintln!("Total (SA + correction) elapsed: {}", format_duration(total_secs));

    Ok(())
}

use std::fmt;

#[derive(Clone, Copy, Debug, Default, PartialEq)]
pub struct Point {
    pub x: f32,
    pub y: f32,
}

#[derive(Clone, Debug)]
pub struct Setup {
    pub cities: usize,
    pub cycles: u64,
    pub print_every: u64,
    pub t0: f32,
    pub k: f32,
    /// +1 = minimize (default), -1 = maximize
    pub variant: i32,
    pub xsize: f32,
    pub ysize: f32,
    pub mix: bool,
}

impl Setup {
    pub fn normalize(&mut self) {
        self.variant = if self.variant >= 0 { 1 } else { -1 };
        if self.cities == 0 {
            self.cities = 1;
        }
        if self.print_every == 0 {
            self.print_every = 1;
        }
    }
}

impl fmt::Display for Setup {
    fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
        write!(
            f,
            "cities={}, cycles={}, Pr={}, T0={}, k={}, var={}, x={}, y={}, mix={}",
            self.cities,
            self.cycles,
            self.print_every,
            self.t0,
            self.k,
            self.variant,
            self.xsize,
            self.ysize,
            if self.mix { 1 } else { 0 }
        )
    }
}

#[derive(Clone, Debug)]
pub enum Command {
    /// Generate random cities and run SA. Equivalent to the 8-arg mode in the original C program.
    Generate {
        cities: usize,
        name: String,
        cycles: u64,
        print_every: u64,
        t0: f32,
        k: f32,
        xsize: f32,
        ysize: f32,
        maximize: bool,
    },
    /// Load `<name>.set` + `<name>.conf` and run SA.
    Load { name: String, maximize: bool },
}

use crate::types::Command;
use std::env;

fn is_number(s: &str) -> bool {
    !s.is_empty() && s.chars().all(|c| c.is_ascii_digit())
}

/// Parse CLI arguments.
///
/// Supported forms:
///
/// 1) Generate + run:
///    `tsp_sa N NAME Cyc Pr T0 k x y [maximize]`
///
/// 2) Load + run:
///    `tsp_sa NAME [maximize]`
pub fn parse_args() -> Result<Command, String> {
    let mut args: Vec<String> = env::args().collect();
    // drop program name
    if args.is_empty() {
        return Err("missing argv".into());
    }
    args.remove(0);

    if args.is_empty() {
        return Err(usage());
    }

    let maximize = args
        .last()
        .map(|s| s.eq_ignore_ascii_case("maximize") || s.eq_ignore_ascii_case("max"))
        .unwrap_or(false);
    if maximize {
        args.pop();
    }

    // generate mode if first argument is an integer N
    if args.len() >= 8 && is_number(&args[0]) {
        let cities: usize = args[0].parse().map_err(|_| "N must be an integer".to_string())?;
        let name = args[1].clone();
        let cycles: u64 = args[2].parse().map_err(|_| "Cyc must be u64".to_string())?;
        let print_every: u64 = args[3].parse().map_err(|_| "Pr must be u64".to_string())?;
        let t0: f32 = args[4].parse().map_err(|_| "T0 must be f32".to_string())?;
        let k: f32 = args[5].parse().map_err(|_| "k must be f32".to_string())?;
        let xsize: f32 = args[6].parse().map_err(|_| "x must be f32".to_string())?;
        let ysize: f32 = args[7].parse().map_err(|_| "y must be f32".to_string())?;

        return Ok(Command::Generate {
            cities,
            name,
            cycles,
            print_every,
            t0,
            k,
            xsize,
            ysize,
            maximize,
        });
    }

    // load mode
    if args.len() == 1 {
        return Ok(Command::Load {
            name: args[0].clone(),
            maximize,
        });
    }

    Err(usage())
}

pub fn usage() -> String {
    [
        "Usage:",
        "  tsp_sa N NAME Cyc Pr T0 k x y [maximize]   # generate cities, run SA",
        "  tsp_sa NAME [maximize]                    # load NAME.set + NAME.conf, run SA",
        "",
        "Notes:",
        "  - 'maximize' flips the objective (find longest tour instead of shortest).",
        "  - Outputs are compatible with the original C program (NAME.* and trajectory.mol).",
    ]
    .join("\n")
}

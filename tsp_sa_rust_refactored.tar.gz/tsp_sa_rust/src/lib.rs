//! Simulated annealing solver for a 2D Traveling Salesman Problem.
//!
//! This crate provides a small library (`tsp_sa`) plus a CLI binary (`tsp_sa`).

pub mod cli;
pub mod io;
pub mod sa;
pub mod tsp;
pub mod types;

pub use crate::sa::run;
pub use crate::types::{Point, Setup};

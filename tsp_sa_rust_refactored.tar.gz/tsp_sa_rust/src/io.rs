use crate::types::{Point, Setup};
use std::collections::HashMap;
use std::fs::{File, OpenOptions};
use std::io::{self, BufRead, BufReader, Write};
use std::path::Path;

pub fn file_exists(path: &str) -> bool {
    Path::new(path).exists()
}

pub fn write_conf(path: &str, tour: &[Point]) -> io::Result<()> {
    let mut f = File::create(path)?;
    for p in tour {
        writeln!(f, "{:.8}\t{:.8}", p.x, p.y)?;
    }
    Ok(())
}

pub fn write_set(path: &str, setup: &Setup) -> io::Result<()> {
    let mut f = File::create(path)?;
    writeln!(f, "Cityes= {}", setup.cities)?;
    writeln!(f, "Cyc= {}", setup.cycles)?;
    writeln!(f, "Pr= {}", setup.print_every)?;
    writeln!(f, "T0= {}", setup.t0)?;
    writeln!(f, "k= {}", setup.k)?;
    writeln!(f, "var= {}", setup.variant)?;
    writeln!(f, "x= {}", setup.xsize)?;
    writeln!(f, "y= {}", setup.ysize)?;
    writeln!(f, "mix= {}", if setup.mix { 1 } else { 0 })?;
    Ok(())
}

pub fn read_set(path: &str) -> io::Result<Setup> {
    if !file_exists(path) {
        return Err(io::Error::new(io::ErrorKind::NotFound, format!("Missing file: {path}")));
    }
    let f = File::open(path)?;
    let reader = BufReader::new(f);

    let mut map = HashMap::<String, String>::new();
    for line in reader.lines() {
        let line = line?;
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        if let Some((k, v)) = line.split_once('=') {
            map.insert(k.trim().to_string(), v.trim().to_string());
        }
    }

    let mut setup = Setup {
        cities: parse_required(&map, "Cityes")?,
        cycles: parse_required(&map, "Cyc")?,
        print_every: parse_required(&map, "Pr")?,
        t0: parse_required(&map, "T0")?,
        k: parse_required(&map, "k")?,
        variant: parse_required(&map, "var")?,
        xsize: parse_required(&map, "x")?,
        ysize: parse_required(&map, "y")?,
        mix: map
            .get("mix")
            .map(|s| s.trim().parse::<i32>().map(|v| v != 0).unwrap_or(true))
            .unwrap_or(true),
    };
    setup.normalize();
    Ok(setup)
}

fn parse_required<T: std::str::FromStr>(map: &HashMap<String, String>, key: &str) -> io::Result<T> {
    map.get(key)
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, format!("Can't read {key}")))?
        .parse::<T>()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, format!("Bad {key}")))
}

pub fn read_conf(path: &str, cities: usize) -> io::Result<Vec<Point>> {
    if !file_exists(path) {
        return Err(io::Error::new(io::ErrorKind::NotFound, format!("Missing file: {path}")));
    }
    let f = File::open(path)?;
    let reader = BufReader::new(f);
    let mut tour = Vec::with_capacity(cities);
    for line in reader.lines() {
        let line = line?;
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() < 2 {
            continue;
        }
        let x: f32 = parts[0]
            .parse()
            .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad x in conf"))?;
        let y: f32 = parts[1]
            .parse()
            .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad y in conf"))?;
        tour.push(Point { x, y });
        if tour.len() == cities {
            break;
        }
    }
    if tour.len() != cities {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("Expected {cities} points in {path}, got {}", tour.len()),
        ));
    }
    Ok(tour)
}

fn write_f32_le<W: Write>(w: &mut W, v: f32) -> io::Result<()> {
    w.write_all(&v.to_le_bytes())
}

pub fn create_plb(path: &str, header: [f32; 2]) -> io::Result<()> {
    let mut f = File::create(path)?;
    write_f32_le(&mut f, header[0])?;
    write_f32_le(&mut f, header[1])?;
    Ok(())
}

pub fn append_frame_plb(path: &str, xsize: f32, ysize: f32, z: f32, tour: &[Point]) -> io::Result<()> {
    let mut f = OpenOptions::new().append(true).open(path)?;
    write_f32_le(&mut f, xsize)?;
    write_f32_le(&mut f, ysize)?;
    write_f32_le(&mut f, z)?;
    for p in tour {
        write_f32_le(&mut f, p.x)?;
        write_f32_le(&mut f, p.y)?;
        write_f32_le(&mut f, z)?;
    }
    Ok(())
}

pub fn create_mol(path: &str, n_minus_1: usize, max_cycle: u64, print_every: u64, t0: f32, k: f32) -> io::Result<()> {
    let mut f = OpenOptions::new().create(true).append(true).open(path)?;
    let n_atoms = n_minus_1 + 1;
    writeln!(f, "! Soubor vygenerovan v ramci reseni problemu obchodniho cestujiciho.")?;
    writeln!(
        f,
        "!Number of cities={}, Steps={}, Printed every {} steps, Initial Temperature= {}, k={}",
        n_atoms, max_cycle, print_every, t0, k
    )?;
    writeln!(f)?;
    writeln!(f, "number_of_atoms = {}", n_atoms)?;
    writeln!(f, "number_of_frames = {}", max_cycle / print_every + 1)?;
    writeln!(f, "atom_types = 1")?;
    writeln!(f, "atom_type = 1")?;
    writeln!(f, "number_of_bonds = 0")?;
    writeln!(f)?;
    writeln!(f)?;
    writeln!(f, "atoms")?;
    writeln!(f, "! i  atom-id  a-type charge chir nbonds bound_atoms")?;

    // Ring connectivity (same as original C/Rust rewrite).
    if n_atoms >= 1 {
        writeln!(f, "{:3} {:3}-H \t H      0    0      2     {} {}", 0, 0, 1, n_minus_1)?;
        for i in 1..n_minus_1 {
            writeln!(f, "{:3} {:3}-H \t H      0    0      2     {} {}", i, i, i - 1, i + 1)?;
        }
        if n_minus_1 > 0 {
            writeln!(
                f,
                "{:3} {:3}-H \t H      0    0      2     {} {}",
                n_minus_1,
                n_minus_1,
                n_minus_1 - 1,
                0
            )?;
        }
    }

    Ok(())
}

pub fn write_fin(path: &str, best_len: f32, best_cycle: u64, elapsed_s: f32) -> io::Result<()> {
    let mut f = File::create(path)?;
    writeln!(f, "Best_Length= {}", best_len)?;
    writeln!(f, "Best_Cycle= {}", best_cycle)?;
    writeln!(f, "Elapsed_s= {}", elapsed_s)?;
    Ok(())
}

pub fn write_trip(path: &str, best_len: f32, best_cycle: u64, setup: &Setup) -> io::Result<()> {
    let mut f = File::create(path)?;
    writeln!(f, "# TSP (simulated annealing)")?;
    writeln!(f, "# {setup}")?;
    writeln!(f, "Best_Length= {best_len}")?;
    writeln!(f, "Best_Cycle= {best_cycle}")?;
    Ok(())
}

/// Create/overwrite the `.trip` file with its header (compatible with original C).
pub fn init_trip(path: &str, setup: &Setup) -> io::Result<()> {
    let mut f = File::create(path)?;
    writeln!(
        f,
        "!Number of cities={}, Steps={}, Printed every {} steps, Initial Temperature= {}, k={}{}",
        setup.cities,
        setup.cycles,
        setup.print_every,
        setup.t0,
        setup.k,
        if setup.variant < 0 { " (maximize)" } else { "" }
    )?;
    writeln!(f, "!Steps   Frames   Temperature   Length of trip")?;
    Ok(())
}

/// Append one line of progress to the `.trip` file.
pub fn append_trip_row(path: &str, step: u64, print_every: u64, temperature: f32, length_signed: f32) -> io::Result<()> {
    let mut f = OpenOptions::new().create(true).append(true).open(path)?;
    let frame = if print_every == 0 { 0 } else { step / print_every };
    writeln!(f, "{:15} {:10} {:12.6} {:12.6}", step, frame, temperature, length_signed.abs())?;
    Ok(())
}

use crate::types::Point;

#[inline]
fn dist(a: Point, b: Point) -> f32 {
    let dx = a.x - b.x;
    let dy = a.y - b.y;
    (dx * dx + dy * dy).sqrt()
}

/// Total tour length, including closing edge (last -> first).
pub fn tour_length(tour: &[Point]) -> f32 {
    if tour.len() <= 1 {
        return 0.0;
    }
    let mut sum = 0.0;
    for i in 0..tour.len() {
        let j = (i + 1) % tour.len();
        sum += dist(tour[i], tour[j]);
    }
    sum
}

/// Compute change in tour length for a 2-opt reversal of segment [i, k] inclusive.
/// Uses cyclic indexing, so i==0 is safe.
pub fn delta_2opt(tour: &[Point], i: usize, k: usize) -> f32 {
    let n = tour.len();
    if n < 4 || i >= n || k >= n || i == k {
        return 0.0;
    }
    let (i, k) = if i < k { (i, k) } else { (k, i) };
    if i == 0 && k == n - 1 {
        // Reversing whole cycle doesn't change length.
        return 0.0;
    }

    let a = (i + n - 1) % n;
    let b = i;
    let c = k;
    let d = (k + 1) % n;

    // Remove edges (a-b) and (c-d), add edges (a-c) and (b-d)
    dist(tour[a], tour[c]) + dist(tour[b], tour[d]) - dist(tour[a], tour[b]) - dist(tour[c], tour[d])
}

/// Apply 2-opt reversal of segment [i, k] inclusive.
pub fn apply_2opt(tour: &mut [Point], i: usize, k: usize) {
    let n = tour.len();
    if n < 2 || i >= n || k >= n || i == k {
        return;
    }
    let (i, k) = if i < k { (i, k) } else { (k, i) };
    tour[i..=k].reverse();
}

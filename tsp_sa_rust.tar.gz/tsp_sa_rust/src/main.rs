use itertools::Itertools;
use rand::prelude::*;
use std::env;
use std::fs::{File, OpenOptions};
use std::io::{self, BufRead, BufReader, Write};
use std::path::Path;
use std::time::Instant;

#[derive(Clone, Copy, Debug)]
struct Point {
    x: f32,
    y: f32,
}

#[derive(Clone, Debug)]
struct Setup {
    cities: usize,
    cycles: u64,
    print_every: u64,
    t0: f32,
    k: f32,
    variant: i32, // +1 = minimize, -1 = maximize
    xsize: f32,
    ysize: f32,
    mix: bool,
}

fn file_exists(path: &str) -> bool {
    Path::new(path).exists()
}

fn write_conf(path: &str, tour: &[Point]) -> io::Result<()> {
    let mut f = File::create(path)?;
    for p in tour {
        writeln!(f, "{:.8}\t{:.8}", p.x, p.y)?;
    }
    Ok(())
}

fn write_set(path: &str, setup: &Setup) -> io::Result<()> {
    let mut f = File::create(path)?;
    writeln!(f, "Cityes= {}", setup.cities)?;
    writeln!(f, "Cyc= {}", setup.cycles)?;
    writeln!(f, "Pr= {}", setup.print_every)?;
    writeln!(f, "T0= {}", setup.t0)?;
    writeln!(f, "k= {}", setup.k)?;
    writeln!(f, "var= {}", setup.variant)?;
    writeln!(f, "x= {}", setup.xsize)?;
    writeln!(f, "y= {}", setup.ysize)?;
    writeln!(f, "mix= {}", if setup.mix { 1 } else { 0 })?;
    Ok(())
}

fn read_set(path: &str) -> io::Result<Setup> {
    if !file_exists(path) {
        return Err(io::Error::new(io::ErrorKind::NotFound, format!("Missing file: {path}")));
    }
    let f = File::open(path)?;
    let reader = BufReader::new(f);

    let mut map = std::collections::HashMap::<String, String>::new();
    for line in reader.lines() {
        let line = line?;
        let line = line.trim();
        if line.is_empty() {
            continue;
        }
        if let Some((k, v)) = line.split_once('=') {
            map.insert(k.trim().to_string(), v.trim().to_string());
        }
    }

    let cities: usize = map
        .get("Cityes")
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "Can't read Cityes"))?
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad Cityes"))?;
    let cycles: u64 = map
        .get("Cyc")
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "Can't read Cyc"))?
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad Cyc"))?;
    let print_every: u64 = map
        .get("Pr")
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "Can't read Pr"))?
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad Pr"))?;
    let t0: f32 = map
        .get("T0")
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "Can't read T0"))?
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad T0"))?;
    let k: f32 = map
        .get("k")
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "Can't read k"))?
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad k"))?;
    let variant: i32 = map
        .get("var")
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "Can't read var"))?
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad var"))?;
    let xsize: f32 = map
        .get("x")
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "Can't read x"))?
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad x"))?;
    let ysize: f32 = map
        .get("y")
        .ok_or_else(|| io::Error::new(io::ErrorKind::InvalidData, "Can't read y"))?
        .parse()
        .map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad y"))?;
    let mix: bool = map
        .get("mix")
        .unwrap_or(&"1".to_string())
        .trim()
        .parse::<i32>()
        .map(|v| v != 0)
        .unwrap_or(true);

    Ok(Setup {
        cities,
        cycles,
        print_every,
        t0,
        k,
        variant: if variant >= 0 { 1 } else { -1 },
        xsize,
        ysize,
        mix,
    })
}

fn read_conf(path: &str, cities: usize) -> io::Result<Vec<Point>> {
    if !file_exists(path) {
        return Err(io::Error::new(io::ErrorKind::NotFound, format!("Missing file: {path}")));
    }
    let f = File::open(path)?;
    let reader = BufReader::new(f);
    let mut tour = Vec::with_capacity(cities);
    for line in reader.lines() {
        let line = line?;
        let parts: Vec<&str> = line.split_whitespace().collect();
        if parts.len() < 2 {
            continue;
        }
        let x: f32 = parts[0].parse().map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad x in conf"))?;
        let y: f32 = parts[1].parse().map_err(|_| io::Error::new(io::ErrorKind::InvalidData, "Bad y in conf"))?;
        tour.push(Point { x, y });
        if tour.len() == cities {
            break;
        }
    }
    if tour.len() != cities {
        return Err(io::Error::new(
            io::ErrorKind::InvalidData,
            format!("Expected {cities} points in {path}, got {}", tour.len()),
        ));
    }
    Ok(tour)
}

fn write_f32_le<W: Write>(w: &mut W, v: f32) -> io::Result<()> {
    w.write_all(&v.to_le_bytes())
}

fn create_plb(path: &str, header: [f32; 2]) -> io::Result<()> {
    let mut f = File::create(path)?;
    write_f32_le(&mut f, header[0])?;
    write_f32_le(&mut f, header[1])?;
    Ok(())
}

fn append_frame_plb(path: &str, xsize: f32, ysize: f32, z: f32, tour: &[Point]) -> io::Result<()> {
    let mut f = OpenOptions::new().append(true).open(path)?;
    // BoxSize[3]
    write_f32_le(&mut f, xsize)?;
    write_f32_le(&mut f, ysize)?;
    write_f32_le(&mut f, z)?;
    // XYZ per city
    for p in tour {
        write_f32_le(&mut f, p.x)?;
        write_f32_le(&mut f, p.y)?;
        write_f32_le(&mut f, z)?;
    }
    Ok(())
}

fn create_mol(path: &str, n_minus_1: usize, max_cycle: u64, print_every: u64, t0: f32, k: f32) -> io::Result<()> {
    // The original C appends to trajectory.mol; we'll keep same behavior for compatibility.
    let mut f = OpenOptions::new().create(true).append(true).open(path)?;
    let n_atoms = n_minus_1 + 1;
    writeln!(f, "! Soubor vygenerovan v ramci reseni problemu obchodniho cestujiciho.")?;
    writeln!(
        f,
        "!Number of cities={}, Steps={}, Printed every {} steps, Initial Temperature= {}, k={}",
        n_atoms, max_cycle, print_every, t0, k
    )?;
    writeln!(f)?;
    writeln!(f, "number_of_atoms = {}", n_atoms)?;
    writeln!(f)?;
    writeln!(f)?;
    writeln!(f, "atoms")?;
    writeln!(f, "! i  atom-id  a-type charge chir nbonds bound_atoms")?;

    // Ring connectivity (same as C)
    if n_atoms >= 1 {
        writeln!(f, "{:3} {:3}-H \t H      0    0      2     {} {}", 0, 0, 1, n_minus_1)?;
        for i in 1..n_minus_1 {
            writeln!(f, "{:3} {:3}-H \t H      0    0      2     {} {}", i, i, i - 1, i + 1)?;
        }
        if n_minus_1 > 0 {
            writeln!(
                f,
                "{:3} {:3}-H \t H      0    0      2     {} {}",
                n_minus_1,
                n_minus_1,
                n_minus_1 - 1,
                0
            )?;
        }
    }
    Ok(())
}

fn write_trip(path: &str, step: u64, print_every: u64, temperature: f32, length: f32) -> io::Result<()> {
    let mut f = OpenOptions::new().create(true).append(true).open(path)?;
    let frame = step / print_every;
    writeln!(f, "{:15} {:10} {:12.6} {:12.6}", step, frame, temperature, length.abs())?;
    Ok(())
}

fn distance(a: Point, b: Point) -> f32 {
    let dx = a.x - b.x;
    let dy = a.y - b.y;
    (dx * dx + dy * dy).sqrt()
}

fn tour_length(tour: &[Point]) -> f32 {
    let n = tour.len();
    if n < 2 {
        return 0.0;
    }
    let mut s = 0.0f32;
    for i in 0..n {
        let j = (i + 1) % n;
        s += distance(tour[i], tour[j]);
    }
    s
}

/// Delta for performing a 2-opt reversal of the segment [i..=k] in a cyclic tour.
/// Uses cyclic neighbor indices so i can be 0 safely.
fn delta_2opt(tour: &[Point], i: usize, k: usize) -> f32 {
    let n = tour.len();
    debug_assert!(i < n && k < n && i != k);
    let a = (i + n - 1) % n;
    let b = i;
    let c = k;
    let d = (k + 1) % n;

    // If edges are adjacent in a way that makes 2-opt degenerate, delta is 0.
    if b == c || a == c || b == d {
        return 0.0;
    }

    let old = distance(tour[a], tour[b]) + distance(tour[c], tour[d]);
    let newv = distance(tour[a], tour[c]) + distance(tour[b], tour[d]);
    newv - old
}

fn apply_2opt_reverse(tour: &mut [Point], i: usize, k: usize) {
    let (lo, hi) = if i < k { (i, k) } else { (k, i) };
    tour[lo..=hi].reverse();
}

fn format_duration(secs: f64) -> String {
    if secs < 60.0 {
        return format!("{secs:.3} sec");
    }
    let mut seconds = secs;
    let minutes = (seconds / 60.0).floor() as i64;
    seconds -= (minutes as f64) * 60.0;
    if minutes < 60 {
        return format!("{minutes} min {seconds:.3} sec");
    }
    let hours = (minutes / 60) as i64;
    let minutes2 = minutes - hours * 60;
    if hours < 24 {
        return format!("{hours} h {minutes2} min {seconds:.3} sec");
    }
    let days = hours / 24;
    let hours2 = hours - days * 24;
    format!("{days} d {hours2} h {minutes2} min {seconds:.3} sec")
}

/// Local brute-force correction: for each start position m, optimize the order of the next P cities (cyclic),
/// keeping the rest of the tour fixed. This mirrors the original C "MojeOprava" idea but with safe indexing.
fn brute_local_correction(tour: &mut Vec<Point>, variant: i32, passes: usize, window: usize) -> f64 {
    let n = tour.len();
    if n < window + 2 {
        return 0.0;
    }

    let start = Instant::now();
    for _ in 0..passes {
        for m in 0..n {
            let prev = (m + n - 1) % n;
            let next = (m + window) % n;

            // indices of the window cities to permute
            let idxs: Vec<usize> = (0..window).map(|t| (m + t) % n).collect();
            let window_pts: Vec<Point> = idxs.iter().map(|&ix| tour[ix]).collect();

            let mut best = window_pts.clone();
            let mut best_len = if variant >= 0 { f32::INFINITY } else { f32::NEG_INFINITY };

            for perm in window_pts.iter().copied().permutations(window) {
                let mut len = distance(tour[prev], perm[0]);
                for i in 0..window - 1 {
                    len += distance(perm[i], perm[i + 1]);
                }
                len += distance(perm[window - 1], tour[next]);

                let better = if variant >= 0 { len < best_len } else { len > best_len };
                if better {
                    best_len = len;
                    best = perm;
                }
            }

            // apply best permutation back into tour
            for (dst, p) in idxs.into_iter().zip(best.into_iter()) {
                tour[dst] = p;
            }
        }
    }
    start.elapsed().as_secs_f64()
}

fn usage() {
    eprintln!("WRONG number of arguments.");
    eprintln!("Program for solving Travelling salesman problem by simulated annealing.");
    eprintln!("Usage:");
    eprintln!("  tsp_sa N NAME Cyc Pr T0 k xsize ysize [maximize]");
    eprintln!("    N      : number of cities (must be > 4)");
    eprintln!("    NAME   : job name = base name of output files");
    eprintln!("    Cyc    : number of cycles (steps)");
    eprintln!("    Pr     : output period (steps)");
    eprintln!("    T0     : initial temperature");
    eprintln!("    k      : cooling constant (e.g. 0.0001)");
    eprintln!("    xsize ysize : box sizes");
    eprintln!("    maximize (optional): if present, maximize tour length instead of minimize");
    eprintln!();
    eprintln!("Alternative:");
    eprintln!("  tsp_sa NAME");
    eprintln!("    Requires NAME.set and NAME.conf to exist.");
}

fn main() -> io::Result<()> {
    let args: Vec<String> = env::args().collect();
    if args.len() != 2 && args.len() != 9 && args.len() != 10 {
        usage();
        std::process::exit(1);
    }

    let mut rng = rand::rngs::StdRng::from_entropy();
    let z: f32 = 0.0;
    let mol_path = "trajectory.mol";

    // Output file names
    let (name, mut setup, mut tour): (String, Setup, Vec<Point>) = if args.len() == 2 {
        let name = args[1].clone();
        let set_path = format!("{name}.set");
        let conf_path = format!("{name}.conf");
        let mut setup = read_set(&set_path)?;
        if setup.cities <= 4 {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Number of cities must be > 4"));
        }
        let mut tour = read_conf(&conf_path, setup.cities)?;

        if setup.mix {
            tour.shuffle(&mut rng);
        }
        (name, setup, tour)
    } else {
        // Args: N NAME Cyc Pr T0 k xsize ysize [maximize]
        let cities: usize = args[1].parse().map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "Bad N"))?;
        if cities <= 4 {
            return Err(io::Error::new(io::ErrorKind::InvalidInput, "Number of cities must be > 4"));
        }
        let name = args[2].clone();
        let cycles: u64 = args[3].parse().map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "Bad Cyc"))?;
        let print_every: u64 = args[4].parse().map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "Bad Pr"))?;
        let t0: f32 = args[5].parse().map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "Bad T0"))?;
        let k: f32 = args[6].parse().map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "Bad k"))?;
        let xsize: f32 = args[7].parse().map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "Bad xsize"))?;
        let ysize: f32 = args[8].parse().map_err(|_| io::Error::new(io::ErrorKind::InvalidInput, "Bad ysize"))?;

        let variant = if args.len() == 10 { -1 } else { 1 };

        let setup = Setup {
            cities,
            cycles,
            print_every,
            t0,
            k,
            variant,
            xsize,
            ysize,
            mix: true, // when generating random initial tour, shuffling is irrelevant
        };

        // Generate initial random configuration in the box.
        let mut tour = Vec::with_capacity(cities);
        for _ in 0..cities {
            let x = rng.gen_range(0.0f32..xsize);
            let y = rng.gen_range(0.0f32..ysize);
            tour.push(Point { x, y });
        }

        (name, setup, tour)
    };

    // Write/overwrite the standard outputs (same naming scheme as C).
    let trip_path = format!("{name}.trip");
    let conf_path = format!("{name}.conf");
    let set_path = format!("{name}.set");
    let fin_path = format!("{name}.fin");
    let plb_path = format!("{name}.plb");

    // Write initial configuration + setup (for reproducibility)
    write_conf(&conf_path, &tour)?;
    write_set(&set_path, &setup)?;

    // Create .plb and .mol
    create_plb(&plb_path, [setup.cities as f32, -3.0])?;
    create_mol(mol_path, setup.cities - 1, setup.cycles, setup.print_every, setup.t0, setup.k)?;

    // Create/overwrite .trip header
    {
        let mut f = File::create(&trip_path)?;
        writeln!(
            f,
            "!Number of cities={}, Steps={}, Printed every {} steps, Initial Temperature= {}, k={}",
            setup.cities, setup.cycles, setup.print_every, setup.t0, setup.k
        )?;
        writeln!(f, "!Steps   Frames   Temperature   Length of trip")?;
    }

    // Write initial frame
    append_frame_plb(&plb_path, setup.xsize, setup.ysize, z, &tour)?;
    let init_len = (setup.variant as f32) * tour_length(&tour);
    write_trip(&trip_path, 1, setup.print_every, setup.t0, init_len)?;

    // Simulated annealing (2-opt moves)
    let korr = (setup.xsize * setup.ysize).sqrt().max(1e-12); // avoid div0
    let sa_start = Instant::now();
    let mut temperature = setup.t0;

    // We keep 1-based step numbering like the original C code.
    for step in 1..=setup.cycles {
        // Cooling schedule from the original C (cast to f64 for stability).
        let max_cycle = setup.cycles as f64;
        let kf = setup.k as f64;
        let t0f = setup.t0 as f64;
        let denom = (step as f64) + (max_cycle * kf - 1.0);
        temperature = (max_cycle * kf * t0f / denom) as f32;

        // pick i, k (non-trivial segment)
        let n = tour.len();
        let mut i = rng.gen_range(0..n);
        let mut k = i;
        while {
            let diff = if i > k { i - k } else { k - i };
            diff < 2 || diff == n - 1
        } {
            k = rng.gen_range(0..n);
        }
        if k < i {
            std::mem::swap(&mut i, &mut k);
        }

        let delta = delta_2opt(&tour, i, k) * (setup.variant as f32);
        let accept = if delta < 0.0 {
            true
        } else {
            let prob = (-(delta as f64) / ((temperature as f64) * (korr as f64))).exp();
            rng.gen::<f64>() < prob
        };

        if accept {
            apply_2opt_reverse(&mut tour, i, k);
        }

        if setup.print_every != 0 && step % setup.print_every == 0 {
            append_frame_plb(&plb_path, setup.xsize, setup.ysize, z, &tour)?;
            let len = (setup.variant as f32) * tour_length(&tour);
            write_trip(&trip_path, step, setup.print_every, temperature, len)?;
        }
    }

    // If the last step wasn't printed, print a final frame like the C code.
    if setup.print_every != 0 && setup.cycles % setup.print_every != 0 {
        append_frame_plb(&plb_path, setup.xsize, setup.ysize, z, &tour)?;
        let len = (setup.variant as f32) * tour_length(&tour);
        write_trip(&trip_path, setup.cycles, setup.print_every, temperature, len)?;
    }

    let sa_secs = sa_start.elapsed().as_secs_f64();
    {
        let mut f = OpenOptions::new().create(true).append(true).open(&trip_path)?;
        writeln!(f, "!Simulated annealing run time was {}", format_duration(sa_secs))?;
    }
    eprintln!("Simulated annealing run time was {}", format_duration(sa_secs));
    eprintln!("Final tour length from SA: {:.6}", tour_length(&tour));

    // Optional local correction (mirrors the original behavior).
    // Original: run 4 passes (i=0..3) with window size 6.
    let corr_secs = brute_local_correction(&mut tour, setup.variant, 4, 6);
    let final_len = tour_length(&tour);
    append_frame_plb(&plb_path, setup.xsize, setup.ysize, z, &tour)?;
    // Use cycles+1 frame index for correction output (like the C code increments cycle past maxCycle)
    write_trip(&trip_path, setup.cycles + 1, setup.print_every.max(1), temperature, (setup.variant as f32) * final_len)?;

    {
        let mut f = OpenOptions::new().create(true).append(true).open(&trip_path)?;
        writeln!(f, "!My correction run time was {}", format_duration(corr_secs))?;
        writeln!(f, "!Trip length after my correction follows:")?;
        writeln!(f, "!Final length after My correction is: {:.6}", final_len)?;
    }
    eprintln!("My correction run time was {}", format_duration(corr_secs));
    eprintln!("Final length after correction: {:.6}", final_len);

    // Write final configuration
    write_conf(&fin_path, &tour)?;

    let total_secs = sa_start.elapsed().as_secs_f64();
    eprintln!("Total (SA + correction) elapsed: {}", format_duration(total_secs));

    Ok(())
}
